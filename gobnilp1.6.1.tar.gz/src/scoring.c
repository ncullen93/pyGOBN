/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *   GOBNILP Copyright (C) 2012-2015 James Cussens, Mark Bartlett        *
 *                                                                       *
 *   This program is free software; you can redistribute it and/or       *
 *   modify it under the terms of the GNU General Public License as      *
 *   published by the Free Software Foundation; either version 3 of the  *
 *   License, or (at your option) any later version.                     *
 *                                                                       *
 *   This program is distributed in the hope that it will be useful,     *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of      *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU    *
 *   General Public License for more details.                            *
 *                                                                       *
 *   You should have received a copy of the GNU General Public License   *
 *   along with this program; if not, see                                *
 *   <http://www.gnu.org/licenses>.                                      *
 *                                                                       *
 *   Additional permission under GNU GPL version 3 section 7             *
 *                                                                       *
 *   If you modify this Program, or any covered work, by linking or      *
 *   combining it with SCIP (or a modified version of that library),     *
 *   containing parts covered by the terms of the ZIB Academic License,  *
 *   the licensors of this Program grant you additional permission to    *
 *   convey the resulting work.                                          *
 *                                                                       *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/** @file scoring.c
 *  @brief  generates local scores from discrete data using AD trees
 *  @author James Cussens
 *  @author Mark Bartlett
 */

/*#define SCIP_DEBUG*/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <limits.h>
#include <string.h>
#include "scoring.h"
#include "utils.h"
#include "versiongit.h"

#define min(A,B) ((A) < (B) ? (A) : (B))
#define BLOCKSIZE 10000
#define MAXARITY UCHAR_MAX

typedef unsigned int ROW;
typedef unsigned int VARIABLE;
/* indexing with "int" is supposed to be quicker but empirically
   it has been shown that "unsigned char" is substantially faster,
   presumably due to memory savings */
typedef unsigned char ARITY;
typedef unsigned char VALUE;
typedef unsigned int COUNT;
typedef double SCORE;
typedef double SCOREARG;



/** represents data for a 'query', e.g.\ X1=1,X3=2
 *
 * There is always a count of how many datapoints satisfy the query.
 * If, as is most common,  the highest-indexed variable (in the entire dataset) is not mentioned in the query then:
 * if the count < rmin there is a pointer to the datapoint indices for the data
 * otherwise there is a pointer to an 'array' of 'vary nodes' one for each
 * of the remaining variables.
 */
struct adtree                  
{
   COUNT count;                /**< how many datapoints for this query */
   struct varynode *children;  /**< one for each variable specialising  the query, if any (NULL if leaflist is used or there are no specialisations)*/
   ROW *leaflist;              /**< leaflist, if used (NULL otherwise ) */
};
typedef struct adtree ADTREE;

struct varynode                 /** for splitting data on values of a particular variable (variable not stored in varynode) */
{
   struct adtree **children;    /**< children[val] is a pointer to the ADTREE for the specialisation var=val (or NULL if no data for this, mcv) */
   VALUE mcv;                   /**< most common value for this variable (in appropriate 'conditional' dataset) */
};
typedef struct varynode VARYNODE;


union adcontab                 /** a contingency table */
{
   union adcontab *children;   /**< when there are variables, children[val] is the contab for var=val, where var is the first variable */
   COUNT count;                /**< when there are no variables just store a count */
};
typedef union adcontab ADCONTAB;


/** stores a set of downward closed subsets of the variables in a tree
 *
 * Let F be the set of subets, then if \f$x \in F\f$ and  \f$y \subset x\f$ then \f$y \in F\f$
 * (i.e.\ F is downward closed)
 * Each variable is an (unsigned short) int.
 * If, say, {2,4,5} is one of the subsets stored in the tree
 * then subset_tree[2-0][4-3][5-5] is not NULL
 * Note the use of the 'offsets' 0, 3 and 5. Each non-initial offset
 * is the preceding value + 1. This exploits an ordering imposed on the subset and saves memory.
 * if no 'extension' of {2,4,5} is stored then  subset_tree[2-0][4-3][5-4] = bottom_ptr
 */
struct subset_tree
{
   struct subset_tree **children;
};
typedef struct subset_tree SUBSET_TREE;


/** Parent set with its score
 * Note that the child variable is not represented
 */
struct scored_parentset
{
   double score;         /**< 'Local' score for the parent set */
   int nvars;       /**< Number of parents in the parent set */
   VARIABLE *vars;       /**< Array of length nvars listing the parents */
};
typedef struct scored_parentset SCORED_PARENTSET;

static VARIABLE nvars;     /**< Number of variables in the data */
static ARITY *arity;       /**< arity[i] is the arity of variable i */
static int nrows;          /**< Number of rows (i.e. datapoints) in the data */
static VALUE **data;       /**< data[i][j] is the value of variable i in row j */

static double alpha;                        /**< The 'effective sample size' governing the BDeu score */
static int palim;                           /**< Maximum allowed size for a parent set */
static SUBSET_TREE bottom;                  /**< Empty subset tree used to indicate leaf nodes  */
static SUBSET_TREE *bottom_ptr = &bottom;   /**< Pointer to bottom */
static SCIP_Bool fast;                      /**< If true C's lgamma function is used for computing scores, otherwise a slower, more accurate sum of logs */

static SCORE *llh_cache;                    /**< llh_cache[r] is the log-likelihood for (the data projected onto ) the unique subset of variables with rank r */
static COUNT *pos_cells_cache;              /**< pos_cell_cache[r] is the number of non-zero counts in the contingency table for the unique subset of variables with rank r.
                                               A value of zero indicates that neither the correct count nor the the associated llh_cache[r] value has yet been computed */
static int cachesize;                       /**< the current size of the cache for log-likelihoods and pos_cell_cache values (common to both) */
static int cacheblocksize;                  /**< how much to increase the size of the cache for log-likelihoods and pos_cell_cache values when it is too small (common to both) */
static int cachesizelimit;                  /**< the maximum number of log-likelihoods and pos_cell_cache values to cache (limit is common to both) */
static int nvarscachelimit;                 /**< subsets must have size below this to be cached */
static int* nsubsets;                       /**< nsubsets[nvariables] is how many susbsets have size strictly less than nvariables */


/** Gets the index of a named variable
 *  adapted from function of same name in probdata_bn  
 *  @return the index of the given variable in the given parent sets data structure
 */
static
int get_index(
   char* nodeName,     /**< (the name of ) the variable */
   ParentSetData* psd  /**< the parent sets data structure, only nodeNames is set */
   )
{
   int i;

   for( i = 0; i < psd->n; ++i )
      if( strcmp(nodeName, psd->nodeNames[i]) == 0 )
         return i;
   SCIPerrorMessage("Not recognised as a variable name: %s\n", nodeName);
   return -1;
}


/** Parses a string to extract a set from it. 
 * Copied from probdata_bn
 */
static
SCIP_RETCODE parseSet(
   SCIP* scip,            /**< The SCIP instance that this belongs to. */
   ParentSetData* psd,    /**< The data set that the set refers to. */
   const char*  str,      /**< string to parse */
   int*  set,             /**< result set */
   int*  n_set,           /**< length of set */
   SCIP_Bool* success     /**< success flag */
)
{
   const char* t;
   char tmp[SCIP_MAXSTRLEN];
   char nodename[SCIP_MAXSTRLEN];
   int k;
   int nodeindex;

   *n_set = 0;
   t = str;
   while( *t != '\0' )
   {
      k = 0;
      while( *t != '\0' && *t != ',' )
         tmp[k++] = *t++;
      tmp[k] = '\0';
      if( sscanf(tmp, "%d", &nodeindex) != 1 )
      {
         if( sscanf(tmp, "%s", nodename) != 1 )
         {
            SCIPverbMessage(scip, SCIP_VERBLEVEL_MINIMAL, NULL, "Expected variable name. Got: %s\n", tmp);
            *success = FALSE;
            return SCIP_OKAY;
         }
         nodeindex = get_index(nodename, psd);
         if( nodeindex == -1 )
         {
            SCIPverbMessage(scip, SCIP_VERBLEVEL_MINIMAL, NULL, "Expected variable name. Got: %s\n", tmp);
            *success = FALSE;
            return SCIP_OKAY;
         }
      }

      set[(*n_set)++] = nodeindex;

      if( *t == ',' )
         t++;
   }
   return SCIP_OKAY;
}




/** Use a conditional independence (ci) constraint to rule out parents
 *
 *  @param scip The SCIP instance in which to add the constraint.
 *  @param psd The parent set data for the problem.
 *  @param a_str A set
 *  @param b_str B set
 *  @param s_str S (separator) set
 *
 *  @return SCIP_OKAY if the constraint was added successfully or an error code otherwise.
 */
static
SCIP_RETCODE ci_constraint(
   SCIP* scip,
   ParentSetData* psd,
   const char* a_str,
   const char* b_str,
   const char* s_str,
   int** is_parent
   )
{
   int i;
   int j;

   int a[SCIP_MAXSTRLEN];
   int b[SCIP_MAXSTRLEN];
   int sep[SCIP_MAXSTRLEN];
   int n_a;
   int n_b;
   int n_s;

   SCIP_Bool success;

   success = TRUE;
   SCIP_CALL( parseSet(scip, psd, a_str, a, &n_a, &success) );
   if( !success )
      return SCIP_ERROR;
   SCIP_CALL( parseSet(scip, psd, b_str, b, &n_b, &success) );
   if( !success )
      return SCIP_ERROR;
   SCIP_CALL( parseSet(scip, psd, s_str, sep, &n_s, &success) );
   if( !success )
      return SCIP_ERROR;

   for( i = 0; i < n_a; ++i)
      for( j = 0; j < n_b; ++j)
      {
         if( a[i] == b[j] )
            return SCIP_ERROR;
         is_parent[a[i]][b[j]] = -1;
         is_parent[b[j]][a[i]] = -1;
      }
   
   return SCIP_OKAY;
}

/** Processes a constraint on the DAG structure.
 *
 *  @param scip The SCIP instance in which to add the constraint.
 *  @param psd The parent set data relating to this problem, only nodeNames is set.
 *  @param line The description of the constraint to add.
 *  @param is_parent is_parent[i][j] is set to 1 (-1) if j can(not) be a parent of i
 *
 *  @return SCIP_OKAY if the constraint was added or an error otherwise.
 */
static
SCIP_RETCODE process_constraint(
   SCIP* scip,
   ParentSetData* psd,  /**< the parent sets data structure, only nodeNames is set */
   const char* line,
   int** is_parent
   )
{

   int i;
   int j;
   int child;

   char a_str[SCIP_MAXSTRLEN];
   char b_str[SCIP_MAXSTRLEN];
   char s_str[SCIP_MAXSTRLEN];

   if( line[0] == '#' )
      return SCIP_OKAY;

   if( sscanf(line, "%[^~<>-]-%[^~<>-]", a_str, b_str) == 2 )
   {
      i = get_index(a_str, psd);
      j = get_index(b_str, psd);
      if( i == -1 || j == -1 )
         return SCIP_READERROR;

      /* do nothing at present */
   }
   else if( sscanf(line, "~%[^~<>-]-%[^~<>-]", a_str, b_str) == 2 )
   {
      i = get_index(a_str, psd);
      j = get_index(b_str, psd);
      if( i == -1 || j == -1 )
         return SCIP_READERROR;

      is_parent[i][j] = -1;
      is_parent[j][i] = -1;
   }
   else if( sscanf(line, "%[^~<>-]<-%[^~<>-]", a_str, b_str) == 2 )
   {
      i = get_index(a_str, psd);
      j = get_index(b_str, psd);
      if( i == -1 || j == -1 )
         return SCIP_READERROR;

      is_parent[i][j] = 1;
   }
   else if( sscanf(line, "~%[^~<>-]<-%[^~<>-]", a_str, b_str) == 2 )
   {
      i = get_index(a_str, psd);
      j = get_index(b_str, psd);
      if( i == -1 || j == -1 )
         return SCIP_READERROR;

      is_parent[i][j] = -1;
   }
   else if( sscanf(line, "%[^~<>-]->%[^~<>-]<-%[^~<>-]", a_str, s_str, b_str) == 3 )
   {
      i = get_index(a_str, psd);
      j = get_index(b_str, psd);
      child = get_index(s_str, psd);
      if( i == -1 || j == -1 || child == -1 )
         return SCIP_READERROR;

      is_parent[child][i] = 1;
      is_parent[child][j] = 1;
   }
   else if( sscanf(line, "~%[^~<>-]->%[^~<>-]<-%[^~<>-]", a_str, s_str, b_str) == 3 )
   {
      i = get_index(a_str, psd);
      j = get_index(b_str, psd);
      child = get_index(s_str, psd);
      if( i == -1 || j == -1 || child == -1 )
         return SCIP_READERROR;

      /* do nothing at present */
   }
   else if( sscanf(line, "%[^_~<>-]_|_%[^|~<>-]|%[^~<>-]", a_str, b_str, s_str) == 3 )
      ci_constraint(scip, psd, a_str, b_str, s_str, is_parent);
   else if( sscanf(line, "%[^_~<>-]_|_%[^~<>-]", a_str, b_str) == 2 )
      ci_constraint(scip, psd, a_str, b_str, "", is_parent);
   else
   {
      SCIPerrorMessage("Not recognised as a DAG constraint: %s\n", line);
      return SCIP_READERROR;
   }

   return SCIP_OKAY;
}


/** Reads in structural constraints to restrict which parent sets are considered
 *
 *  (Altered version of function of same name in probdata_bn.c)
 *  @param scip The SCIP instance to add the constraint to.
 *  @param psd The parent set data relating to this problem, only nodeNames is set.
 *  @param is_parent is_parent[i][j] = 1 (-1) if j must (not) be a parent of i 
 *  @return SCIP_OKAY if the constraints could be successfully added.
 */
static
SCIP_RETCODE addGeneralDAGConstraints(
   SCIP* scip,
   ParentSetData* psd,
   int** is_parent
   )
{
   int status;
   char s[SCIP_MAXSTRLEN];
   char* dagconstraintsfile;
   FILE* dagconstraints;

   SCIPgetStringParam(scip, "gobnilp/dagconstraintsfile", &dagconstraintsfile);

   if( strcmp(dagconstraintsfile, "") == 0 )
      return SCIP_OKAY;

   dagconstraints = fopen(dagconstraintsfile, "r");
   if( dagconstraints == NULL )
   {
      SCIPerrorMessage("Could not open file %s.\n", dagconstraintsfile);
      return SCIP_NOFILE;
   }

   status = fscanf(dagconstraints, "%[^\n]%*c", s);
   while( status == 1 )
   {
      SCIP_CALL( process_constraint(scip, psd, s, is_parent) );
      status = fscanf(dagconstraints, "%[^\n]%*c", s);
   }

   fclose(dagconstraints);
   return SCIP_OKAY;
}



/** Check whether a particular subset of variables is stored in a tree of subsets
 *
 * @return True iff the subset is stored in the tree of subsets
 */
static SCIP_Bool check_subset(
   SUBSET_TREE *tree,     /**< Set of subsets of variables */
   VARIABLE* vars,        /**< The subset of variables to look for */
   int num_vars,          /**< The number of variables in the subset */
   VARIABLE offset             /**< Offset for this node */
)
{

   SUBSET_TREE *child;

   assert(tree != NULL);
   assert(vars != NULL);
   assert(tree->children != NULL);
   assert(num_vars > 0);
   assert(offset < nvars);

   child = (tree->children)[vars[0] - offset];

   if( child == NULL )
      /* missing entry, subset is not there */
      return FALSE;
   else if( num_vars == 1 )
      /* entry for last remaining variable present */
      return TRUE;
   else if( child == bottom_ptr )
      /* (*num_vars) > 1 but no further variables stored */
      return FALSE;

   /* all OK so for, but further variables to check */
   return check_subset(child, vars + 1, num_vars - 1, vars[0] + 1);
}

/** Delete a tree of subsets */
static void delete_tree(
   SUBSET_TREE *tree,  /**< Tree of subsets to delete */
   VARIABLE length          /**< Number of children of this node */
)
{
   SUBSET_TREE *child;
   VARIABLE i;

   assert(tree != NULL);
   assert(tree->children != NULL);
   assert(length > 0);
   assert(length <= nvars);

   for( i = 0; i < length; ++i )
   {
      child = tree->children[i];
      if( child != NULL && child != bottom_ptr )
         delete_tree(child, length - i - 1);
   }
   free(tree->children);
   free(tree);
}

/** Add a subset to the tree (if not already there ) */
static void add_subset(
   SUBSET_TREE *tree,    /**< Set of subsets of variables */
   VARIABLE* vars,       /**< The subset of variables to add */
   int num_vars,         /**< The number of variables in the subset */
   VARIABLE offset       /**< Offset for this node */
)
{
   int i;
   int size;

   SUBSET_TREE **child_ptr;
   SUBSET_TREE *child;

   assert(tree != NULL);
   assert(vars != NULL);
   assert(tree->children != NULL);
   assert(num_vars > 0);
   assert(offset < nvars);

   child_ptr = &((tree->children)[vars[0] - offset]);
   child = *child_ptr;

   if( num_vars == 1 )
   {
      *child_ptr = bottom_ptr;
      return;
   }

   if( child == NULL || child == bottom_ptr )
   {
      *child_ptr = (SUBSET_TREE *) malloc(sizeof(SUBSET_TREE));
      /* enough room for vars[0]+1, vars[0]+2, ... , nvars-1 */
      size = nvars - vars[0] - 1;
      /* always allocate room for children when a new node created */
      (*child_ptr)->children = (SUBSET_TREE **) malloc(size * sizeof(SUBSET_TREE *));
      for( i = 0; i < size; ++i )
         (*child_ptr)->children[i] = NULL;
   }
   add_subset((*child_ptr), vars + 1, num_vars - 1, vars[0] + 1);
}


static void build_varynode(VARYNODE *varynode, VARIABLE variable, ROW *theserows, COUNT count, int rmin, const int depth, int *n_nodes, const int adtreedepthlim, const int adtreenodeslim);

static void build_adtree(
   ADTREE *adtree,            /**< pointer to ADTREE being built */
   const VARIABLE variable,   /**< first variable to specialise further on, if variable=nvars then there is none */
   ROW *theserows,            /**< datapoint indices for this tree */
   COUNT count,               /**< number of datapoints for this tree */
   const int rmin,            /**< if count below this then create a leaflist */
   const int depth,                 /**< the depth of this node */
   int *n_nodes,              /**< (pointer to) the number of nodes in the ADTREE */
   const int adtreedepthlim,        /**< limit on the depth of the ADTREE */
   const int adtreenodeslim         /**< limit on the number of nodes in the ADTREE */
)
{
   COUNT j;
   VARIABLE var;

   assert(variable < nvars + 1);
   assert(count > 0);
   assert(theserows != NULL);
   assert(adtree != NULL);

   adtree->count = count;
   adtree->leaflist = NULL;
   adtree->children = NULL;

   /* if there can be no further splitting just record count */
   if( variable < nvars )
   {
      /* if count small enough then make a leaflist which is a copy of theserows */
      /* if depth too large or number of nodes too large, similarly just dump records in a leaflist */
      if( (int) count < rmin || depth > adtreedepthlim || *n_nodes > adtreenodeslim )
      {
         adtree->leaflist = (ROW *) malloc(count * sizeof(ROW));
         for( j = 0; j < count; ++j )
            adtree->leaflist[j] = theserows[j];
      }
      /* or create vary nodes - one for each further variable - and recurse */
      else
      {
         adtree->children = (VARYNODE *) malloc((nvars - variable) * sizeof(VARYNODE));
         if( adtree->children == NULL )
            printf("Couldn't allocate memory for vary nodes\n");
         for( var = variable; var < nvars; ++var )
            build_varynode((adtree->children) + (var - variable), var, theserows, count, rmin, depth, n_nodes, adtreedepthlim, adtreenodeslim);
      }
   }

   /* can always free since data indices are always copied */
   free(theserows);
   return;
}

static void build_varynode(
   VARYNODE *varynode,        /**< varynode being built */
   VARIABLE variable,         /**< which variable is being split */
   ROW *theserows,            /**< datapoint indices to divide between values of variable */
   COUNT count,               /**< number of datapoints for this tree */
   const int rmin,
   int depth,                 /**< the depth of this node */
   int *n_nodes,               /**< (pointer to) the number of nodes in the ADTREE */
   const int adtreedepthlim,        /**< limit on the depth of the ADTREE */
   const int adtreenodeslim         /**< limit on the number of nodes in the ADTREE */
)

{

   const VALUE *thisdata = data[variable];
   const ARITY thisarity = arity[variable];
   ROW **childdata;
   COUNT *childcount;
   VALUE val;
   COUNT j;
   VALUE mcv = 0;
   COUNT countmcv = 0;
   ROW row;

   assert(variable < nvars);
   assert(varynode != NULL);
   assert(theserows != NULL);
   assert(count > 0);


   /* initialise data structures for splitting data on values of the variable */
   childdata = (ROW **) malloc(thisarity * sizeof(ROW *));
   if( childdata == NULL )
      printf("Couldn't allocate childdata\n");
   childcount = (COUNT *) malloc(thisarity * sizeof(COUNT));
   if( childcount == NULL )
      printf("Couldn't allocate childcount\n");

   for( val = 0; val < thisarity; ++val )
   {
      /* lazily allocate space of size 'count' for each val
         (which is certainly big enough), perhaps should
         do allocate in small blocks, on demand
      */
      childdata[val] = (ROW *) malloc(count * sizeof(ROW));
      if( childdata[val] == NULL )
         printf("Couldn't allocate childdata_val\n");

      childcount[val] = 0;
   }

   /* split the data for this tree on values of the variable */
   for( j = 0; j < count; ++j )
   {
      row = theserows[j];
      val = thisdata[row];
      childdata[val][childcount[val]++] = row;
   }


   /* find most common value */
   for( val = 0; val < thisarity; ++val )
      if( childcount[val] > countmcv )
      {
         countmcv = childcount[val];
         mcv = val;
      }
   assert(countmcv > 0);
   varynode->mcv = mcv;

   /* throw away rows for mcv and any zero counts resize the others */
   /* resize as soon as possible */
   for( val = 0; val < thisarity; ++val )
   {
      if( val == mcv || childcount[val] == 0 )
         free(childdata[val]);
      else
      {
         childdata[val] = (ROW *) realloc(childdata[val], childcount[val] * sizeof(ROW));
         if( childdata[val] == NULL )
            printf("Couldn't re-allocate childdata_val\n");
      }
   }

   varynode->children = (ADTREE **) malloc(thisarity * sizeof(ADTREE *));
   if( varynode->children == NULL )
      printf("Couldn't allocate memory for AD trees\n");

   variable++;          /* can lead to variable=nvars, ie a fake 'extra' variable */
   for( val = 0; val < thisarity; ++val )
   {
      if( val == mcv || childcount[val] == 0 )
         varynode->children[val] = NULL;
      else
      {
         /* childdata[val] freed in build_adtree (unless it becomes a leaflist) */
         varynode->children[val] = (ADTREE *) malloc(sizeof(ADTREE));
         (*n_nodes)++;
         if( varynode->children[val] == NULL )
            printf("Couldn't allocate memory for AD tree\n");

         build_adtree(varynode->children[val], variable, childdata[val], childcount[val], rmin, depth + 1, n_nodes, adtreedepthlim, adtreenodeslim);
      }
   }

   free(childdata);
   free(childcount);

   return;

}

static void delete_adtree(
   ADTREE *adtree,            /**< pointer to ADTREE being deleted */
   const VARIABLE variable    /**< first variable to specialise further on, if variable=nvars then there is none */
)
{

   VARIABLE var;
   VARYNODE *vn_ptr = adtree->children;
   VARYNODE vn;
   VALUE val;

   if( adtree->leaflist != NULL )
   {
      assert(vn_ptr == NULL);
      free(adtree->leaflist);
   }
   else if( vn_ptr != NULL )
   {
      assert(adtree->leaflist == NULL);
      for( var = variable; var < nvars; ++var )
      {
         vn = vn_ptr[var - variable];
         for( val = 0; val < arity[var]; ++val )
            if( vn.children[val] != NULL )
               delete_adtree(vn.children[val], var + 1);
         free(vn.children);
      }
      free(vn_ptr);
   }
   free(adtree);
   return;
}

/** Construct a contingency table from a leaflist
 *  ( contingency table must be for at least one variable )
 */
static void makecontableaf(
   const ROW *leaflist,       /**< datapoints for this query  */
   const COUNT count,         /**< number of datapoints (in leaflist) */
   VARIABLE *variables,       /**< variables in the contingency table (sorted) */
   int nvariables,            /**< number of variables in the contigency table */
   ADCONTAB* adcontab         /**< (pointer to ) returned contingency table */
)
{

   const VARIABLE firstvar = variables[0];
   const VALUE *firstvardata = data[firstvar];
   const ARITY firstarity = arity[firstvar];

   VALUE val;

   ROW **bin;
   COUNT *bin_size;

   COUNT j;
   ROW row;

   ADCONTAB* adpt;
   ADCONTAB* adpt2;
   ADCONTAB* adpt3;

   VARIABLE secondvar;
   VALUE *secondvardata;
   ARITY secondarity;
   VALUE val2;

   VARIABLE thirdvar;
   VALUE *thirdvardata;
   ARITY thirdarity;
   VALUE val3;

   /* VARIABLE fourthvar; */
   /* VALUE *fourthvardata; */
   /* ARITY fourtharity; */
   /* VALUE val4; */

   SCIP_Bool* poscount;
   VALUE firstvardatarow;

   assert(leaflist != NULL);
   assert(adcontab != NULL);

   if( count == 0 )
   {
      adcontab->children = NULL;
      return;
   }

   adcontab->children = (ADCONTAB *) malloc(firstarity * sizeof(ADCONTAB));
   adpt = adcontab->children;

   /* specialising for one variable is a big win re performance
    ( since no memory allocation )
   */
   if( nvariables == 1 )
   {
      for( val = 0; val < firstarity; ++val )
         (adpt++)->count = 0;
      adpt = adcontab->children;

      for( j = 0; j < count; ++j )
         ((adpt + firstvardata[leaflist[j]])->count)++;

      return;
   }

   if( nvariables == 2 )
   {
      secondvar = variables[1];
      secondvardata = data[secondvar];
      secondarity = arity[secondvar];
      
      poscount = (SCIP_Bool *) malloc(firstarity * sizeof(SCIP_Bool));

      for( val = 0; val < firstarity; ++val )
      {
         adpt->children = (ADCONTAB *) malloc(secondarity * sizeof(ADCONTAB));
         adpt2 = adpt->children;
         for( val2 = 0; val2 < secondarity; ++val2 )
            (adpt2++)->count = 0;
         adpt++;
         poscount[val] = FALSE;
      }
      adpt = adcontab->children;
      
      for( j = 0; j < count; ++j )
      {
         row = leaflist[j];
         firstvardatarow = firstvardata[row];
         poscount[firstvardatarow] = TRUE;
         (((adpt+firstvardatarow)->children)+secondvardata[row])->count++;
      }
      
      for( val = 0; val < firstarity; ++val )
      {
         if( !poscount[val] )
         {
            free(adpt->children);
            adpt->children = NULL;
         }
         adpt++;
      }
      free(poscount);
      
      return;
   }

   if( nvariables == 3 )
   {
      secondvar = variables[1];
      secondvardata = data[secondvar];
      secondarity = arity[secondvar];

      thirdvar = variables[2];
      thirdvardata = data[thirdvar];
      thirdarity = arity[thirdvar];
      
      poscount = (SCIP_Bool *) malloc(firstarity * sizeof(SCIP_Bool));

      for( val = 0; val < firstarity; ++val )
      {
         adpt->children = (ADCONTAB *) malloc(secondarity * sizeof(ADCONTAB));
         adpt2 = adpt->children;
         for( val2 = 0; val2 < secondarity; ++val2 )
         {
            adpt2->children = (ADCONTAB *) malloc(thirdarity * sizeof(ADCONTAB));
            adpt3 = adpt2->children;
            for( val3 = 0; val3 < thirdarity; ++val3 )
               (adpt3++)->count = 0;
            adpt2++;
         }
         adpt++;
         poscount[val] = FALSE;
      }
      adpt = adcontab->children;
      
      for( j = 0; j < count; ++j )
      {
         row = leaflist[j];
         firstvardatarow = firstvardata[row];
         poscount[firstvardatarow] = TRUE;
         (((((adpt+firstvardata[row])->children)+secondvardata[row])->children)+thirdvardata[row])->count++;
      }

      for( val = 0; val < firstarity; ++val )
      {
         if( !poscount[val] )
         {
            adpt2 = adpt->children;
            for( val2 = 0; val2 < secondarity; ++val2 )
            {
               free(adpt2->children);
               adpt2++;
            }

            free(adpt->children);
            adpt->children = NULL;
         }
         adpt++;
      }
      free(poscount);

      
      return;
   }


   /* if( nvariables == 4 ) */
   /* { */
   /*    secondvar = variables[1]; */
   /*    secondvardata = data[secondvar]; */
   /*    secondarity = arity[secondvar]; */

   /*    thirdvar = variables[2]; */
   /*    thirdvardata = data[thirdvar]; */
   /*    thirdarity = arity[thirdvar]; */

   /*    fourthvar = variables[3]; */
   /*    fourthvardata = data[fourthvar]; */
   /*    fourtharity = arity[fourthvar]; */
      
   /*    for( val = 0; val < firstarity; ++val ) */
   /*    { */
   /*       adpt->children = (ADCONTAB *) malloc(secondarity * sizeof(ADCONTAB)); */
   /*       adpt2 = adpt->children; */
   /*       for( val2 = 0; val2 < secondarity; ++val2 ) */
   /*       { */
   /*          adpt2->children = (ADCONTAB *) malloc(thirdarity * sizeof(ADCONTAB)); */
   /*          adpt3 = adpt2->children; */
   /*          for( val3 = 0; val3 < thirdarity; ++val3 ) */
   /*          { */
   /*             adpt3->children = (ADCONTAB *) malloc(fourtharity * sizeof(ADCONTAB)); */
   /*             for( val4 = 0; val4 < fourtharity; ++val4 ) */
   /*                ((adpt3->children)+val4)->count = 0; */
   /*             adpt3++; */
   /*          } */
   /*          adpt2++; */
   /*       } */
   /*       adpt++; */
   /*    } */
   /*    adpt = adcontab->children; */
      
   /*    for( j = 0; j < count; ++j ) */
   /*    { */
   /*       row = leaflist[j]; */
   /*       (((((((adpt+firstvardata[row])->children)+secondvardata[row])->children)+thirdvardata[row])->children)+fourthvardata[row])->count++; */
   /*    } */
      
   /*    return; */
   /* } */


   /* initialise temporary space
      one bin for each value of the first variable */
   bin = (ROW **) malloc(firstarity * sizeof(ROW *));
   bin_size = (COUNT *) malloc(firstarity * sizeof(COUNT));

   for( val = 0; val < firstarity; ++val )
   {
      bin[val] = (ROW *) malloc(count * sizeof(ROW));
      bin_size[val] = 0;
   }

   /* assign each datapoint according to its value for the first variable */
   for( j = 0; j < count; ++j )
   {
      row = leaflist[j];
      val = firstvardata[row];
      bin[val][bin_size[val]++] = row;
   }

   nvariables--;
   variables++;
   for( val = 0; val < firstarity; ++val )
   {
      makecontableaf(bin[val], bin_size[val], variables, nvariables, adpt++);
      free(bin[val]);
   }

   free(bin);
   free(bin_size);

   return;
}

/* /\** Print a contingency table  *\/ */
/* static void print_contab( */
/*    const ADCONTAB *adcontab, */
/*    VARIABLE *variables, */
/*    COUNT nvariables */
/*    ) */
/* { */
/*    VARIABLE firstvar; */
/*    VALUE val, val2; */
/*    COUNT j; */
/*    ARITY i_arity; */

/*    assert( adcontab != NULL ); */

/*    if(  nvariables == 0  ) */
/*    { */
/*       assert( variables == NULL ); */
/*       printf("%d\n",adcontab->count); */
/*       return; */
/*    } */

/*    assert( variables != NULL ); */
/*    assert( nvariables > 0 ); */
/*    firstvar = variables[0]; */
/*    nvariables--; */
/*    if(  nvariables == 0  ) */
/*       variables = NULL; */
/*    else */
/*       variables++; */

/*    for(  val = 0; val < arity[firstvar]; ++val  ) */
/*    { */
/*       printf("var(%d)=%d\n",firstvar,val); */
/*       if(  nvariables > 0  && ((adcontab->children)+val)->children == NULL  ) */
/*       { */
/*          i_arity = 1; */
/*          for(  j = 0; j < nvariables; ++j  ) */
/*             i_arity *= arity[variables[j]]; */
/*          for(  val2 = 0; val2 < i_arity; ++val2  ) */
/*             printf("0\n"); */
/*       } */
/*       else */
/*          print_contab((adcontab->children)+val,variables,nvariables); */
/*    } */
/*    return; */
/* } */




/** Subtract one contingency table from another */
static void subtract_contab(
   ADCONTAB *adcontab1,
   const ADCONTAB *adcontab2,
   VARIABLE *variables,
   int nvariables
)
{

   VALUE val;

   ADCONTAB *pt1;
   ADCONTAB *pt2;
   ARITY firstarity;

   assert(adcontab1 != NULL);
   assert(adcontab2 != NULL);

   if( nvariables == 0 )
   {
      /* *adcontab1 and *adcontab2 must both be counts */
      assert(variables == NULL);
      adcontab1->count -= adcontab2->count;
      return;
   }

   /* *adcontab1 and *adcontab2 must both be ADCONTAB*
    * arrays of the same length */

   assert(variables != NULL);
   assert(nvariables > 0);
   firstarity = arity[variables[0]];
   nvariables--;

   pt1 = adcontab1->children;
   pt2 = adcontab2->children;
   if( nvariables == 0 )
      for( val = 0; val < firstarity; ++val )
         /* subtract_contab(pt1++,pt2++,NULL,0); */
         (pt1++)->count -= (pt2++)->count;
   else
   {
      variables++;
      for( val = 0; val < firstarity; ++val )
      {
         if( pt1->children != NULL && pt2->children != NULL )
            subtract_contab(pt1, pt2, variables, nvariables);
         pt1++;
         pt2++;
      }
   }
   return;
}

/** Compute the (marginal) log-likelihood for a subset of the variables (modulo a constant)
 *
 * to get the true log-likelihood one would need to add lgamma(alpha) - log(alpha+N)
 * to the result of this function, where N is the number of samples. Since local scores
 * are always computed as this_function(family)-this_function(parents), there is no need to compute
 * the constant term
 */
static SCORE log_likelihood(
   const ADCONTAB *adcontab,  /**< contingency table for variables */
   VARIABLE *variables,       /**< the subset of the variables */
   int nvariables,            /**< the size of the subset of the variables */
   const SCOREARG aijk,       /**< effective samples size (ESS) divided by the number of joint instantiations of the subset of variables */
   const SCORE lgaijk,        /**< log(Gamma(aijk)) */
   COUNT *npos_cells_ptr      /**< pointer to number of cells in adcontab with a positive count */
)
{

   VARIABLE firstvar;
   VALUE val;
   SCORE skore;
   ADCONTAB *adval;
   COUNT i;

   if( nvariables == 0 )
   {
      assert(variables == NULL);
      if( adcontab->count > 0 )
      {
         (*npos_cells_ptr)++;
         if( fast )
            return lgamma(adcontab->count + aijk) - lgaijk;
         else
         {
            skore = 0;
            for( i = 0; i < adcontab->count; ++i )
               skore += log(i + aijk);
            return skore;
         }
      }
      else
         return 0;
   }

   assert(variables != NULL);
   assert(nvariables > 0);
   firstvar = variables[0];
   nvariables--;
   skore = 0;
   adval = adcontab->children;
   if( nvariables == 0 )
      /* avoiding a recursive call here provides a surprisingly big speed-up */
      for( val = 0; val < arity[firstvar]; ++val )
      {
         if( adval->count > 0 )
         {
            (*npos_cells_ptr)++;
            if( fast )
               skore += (lgamma(adval->count + aijk) - lgaijk);
            else
               for( i = 0; i < adval->count; ++i )
                  skore += log(i + aijk);
         }
         adval++;
         /*skore += score_contab2(adval++,NULL,0,aijk,lgaijk);*/
      }
   else
   {
      variables++;
      for( val = 0; val < arity[firstvar]; ++val )
      {
         if( adval->children != NULL )
            skore += log_likelihood(adval, variables, nvariables, aijk, lgaijk, npos_cells_ptr);
         adval++;
      }
   }
   return skore;
}




/** Delete a contingency table
 */
static void delete_contab(
   ADCONTAB adcontab,
   VARIABLE *variables,
   int nvariables
)
{
   VALUE val;
   VALUE val2;
   const VARIABLE firstvar = variables[0];
   VARIABLE secondvar;

   assert(variables != NULL);
   assert(nvariables > 0);

   if( nvariables > 1 )
   {
      if( nvariables == 2 )
      {
         for( val = 0; val < arity[firstvar]; ++val )
            if( (adcontab.children[val]).children != NULL )
               free((adcontab.children)[val].children);
      }
      else if( nvariables == 3 )
      {
         secondvar = variables[1];
         for( val = 0; val < arity[firstvar]; ++val )
            if( (adcontab.children[val]).children != NULL )
            {
               for( val2 = 0; val2 < arity[secondvar]; ++val2 )
                  if( ((adcontab.children[val]).children)[val2].children != NULL )
                     free(((adcontab.children)[val].children)[val2].children);
               free((adcontab.children)[val].children);
            }
      }
      else
      {
         variables++;
         nvariables--;
         assert(variables != NULL);
         assert(nvariables > 0);
         for( val = 0; val < arity[firstvar]; ++val )
            if( (adcontab.children[val]).children != NULL )
               delete_contab((adcontab.children)[val], variables, nvariables);
      }
   }
   free(adcontab.children);
   return;
}

/** Construct a contingency table from an adtree
 */
static void makecontab(
   const ADTREE *adtree,      /**< (pointer to) the ADTREE or NULL */
   VARIABLE offset,           /**< TODO */
   VARIABLE *variables,       /**< variables in the sought contingency table (sorted) */
   int nvariables,            /**< number of variables in the contingency table */
   ADCONTAB *adcontab         /**< returned contingency table */
)
{

   VARIABLE firstvar;
   ARITY firstarity;

   VALUE val;
   VALUE mcv;

   VARYNODE vn;
   ADTREE **vnchildren;

   ADCONTAB *ptmcv;
   ADCONTAB *ptval;


   assert(adtree != NULL);
   assert(adcontab != NULL);
   assert(adtree->leaflist == NULL || adtree->children == NULL);
   assert(nvariables > 0 || variables == NULL);

   if( nvariables == 0 )
   {
      adcontab->count = adtree->count;
      return;
   }

   assert(nvariables > 0);
   assert(variables != NULL);

   if( adtree->leaflist != NULL )
   {
      assert(adtree->children == NULL);
      /* construct contingency table directly from data in leaf list */
      makecontableaf(adtree->leaflist, adtree->count, variables, nvariables, adcontab);
      return;
   }

   assert(adtree->children != NULL);
   firstvar = variables[0];
   firstarity = arity[firstvar];

   /* need to create a contab for each value of firstvar */

   /* find varynode for firstvar */
   vn = adtree->children[firstvar - offset];
   mcv = vn.mcv;

   assert(vn.children != NULL);
   assert(mcv < firstarity);

   nvariables--;
   if( nvariables == 0 )
      variables = NULL;
   else
      variables++;

   adcontab->children = (ADCONTAB *) malloc(firstarity * sizeof(ADCONTAB));

   makecontab(adtree, offset, variables, nvariables, (adcontab->children) + mcv);

   ptmcv = (adcontab->children) + mcv;
   ptval = adcontab->children;
   offset = firstvar + 1;
   vnchildren = vn.children;
   for( val = 0; val < firstarity; ++val )
   {
      if( val != mcv )
      {
         if( *vnchildren == NULL )
            (*ptval).children = NULL;
         else
         {
            makecontab(*vnchildren, offset, variables, nvariables, ptval);
            subtract_contab(ptmcv, ptval, variables, nvariables);
         }
      }
      ptval++;
      vnchildren++;
   }
   return;
}

/** Map a subset of (BN) variables to a unique index.
    If A is a subset of B then rank(A) < rank(B)
**/
static int rank_subset(
   VARIABLE *variables,       /**< the subset of the variables */
   int nvariables             /**< the size of the subset of the variables */
)
{

   /* the first subset of size nvariables has rank nsubsets[nvariables]
    it is how many subsets have size strictly less than nvariables */
   int rank = nsubsets[nvariables];
   int i, j, v_choose_iplusone;
   VARIABLE v;
   VARIABLE v2;
   VARIABLE v3;
   VARIABLE v4;

   assert(nvariables < palim + 2);

   switch(nvariables)
   {
   case 0 :
      rank = 0;
      break;
   case 1 :
      rank = 1 + variables[0];
      break;
   case 2 :
      v2 = variables[1];
      assert(v2 > variables[0]);
      /* (C(v1,1) + C(v2,2)) */
      rank += variables[0] + v2 * (v2 - 1) / 2;
      break;
   case 3 :
      v2 = variables[1];
      v3 = variables[2];
      assert(v2 > variables[0]);
      assert(v3 > v2);
      /* (C(v1,1) + C(v2,2)) + C(v3,3) */
      rank += variables[0] + v2 * (v2 - 1) / 2  + v3 * (v3 - 1) * (v3 - 2) / 6;
      break;
   case 4 :
      v2 = variables[1];
      v3 = variables[2];
      v4 = variables[3];
      assert(v2 > variables[0]);
      assert(v3 > v2);
      assert(v4 > v3);
      /* (C(v1,1) + C(v2,2)) + C(v3,3) + C(v4,4) */
      rank += variables[0] + v2 * (v2 - 1) / 2  + v3 * (v3 - 1) * (v3 - 2) / 6  + v4 * (v4 - 1) * (v4 - 2) * (v4 - 3) / 24;
      break;
   default :
      for( i = 0; i < nvariables; ++i )
      {
         assert(i == 0 || variables[i] > v);
         v = variables[i];
         /* compute C(v,i+1)*/
         v_choose_iplusone = 1;
         for( j = 0; j < i + 1; ++j )
         {
            v_choose_iplusone *= (v - j);
            v_choose_iplusone /= (j + 1);
         }
         rank += v_choose_iplusone;
      }
      break;
   }

   assert(rank > -1);

   return rank;
}

/** Compute the (marginal) log-likelihood for a subset of the variables and store in cache, or retrieve from cache if already computed */
static SCORE log_likelihood_cache(
   SCIP* scip,                /**< SCIP instance */
   const ADTREE *adtree,      /**< the data */
   VARIABLE *variables,       /**< the subset of the variables */
   int nvariables,            /**< the size of the subset of the variables */
   COUNT *npos_cells_ptr      /**< pointer to number of cells in adcontab with a positive count */
)
{

   SCORE llh;
   ADCONTAB adcontab;
   int rank;
   double aijk, lgaijk;
   int i, v;
   SCIP_Bool cached = FALSE;

   if( nvariables < nvarscachelimit )
   {
      rank = rank_subset(variables, nvariables);

      if( rank < cachesizelimit )
      {
         while( rank >= cachesize )
         {
            cachesize += cacheblocksize;
            SCIP_CALL( SCIPreallocMemoryArray(scip, &llh_cache, cachesize) );
            SCIP_CALL( SCIPreallocMemoryArray(scip, &pos_cells_cache, cachesize) );
            for( i = cachesize - cacheblocksize; i < cachesize; ++i )
               pos_cells_cache[i] = 0;
         }

         cached = TRUE;


         if( pos_cells_cache[rank] != 0 )
         {
            (*npos_cells_ptr) = pos_cells_cache[rank];
            return llh_cache[rank];
         }
      }
   }

   aijk = alpha;
   for( v = 0; v < nvariables; ++v )
      aijk /= arity[variables[v]];
   lgaijk = lgamma(aijk);
   makecontab(adtree, 0, variables, nvariables, &adcontab);
   (*npos_cells_ptr) = 0;
   llh = log_likelihood(&adcontab, variables, nvariables, aijk, lgaijk, npos_cells_ptr);
   assert(*npos_cells_ptr > 0);
   if( nvariables > 0 )
      delete_contab(adcontab, variables, nvariables);

   if( cached )
   {
      llh_cache[rank] = llh;
      pos_cells_cache[rank] = *npos_cells_ptr;
   }

   return llh;
}


/** Compare two scored parent sets according to score
 *
 * For use with qsort, so arguments have type void*
 * @return -1 if first has higher score, else 1
 */
static int sps_sort(
   const void *p1,   /**< First scored parent set */
   const void *p2    /**< Second scored parent set */
)
{
   const SCORED_PARENTSET **sps1 = (const SCORED_PARENTSET **) p1;
   const SCORED_PARENTSET **sps2 = (const SCORED_PARENTSET **) p2;
   if( ((*sps1)->score) > ((*sps2)->score) )
      return -1;
   else
      return 1;
}

/** Add scoring parameters */
SCIP_RETCODE SC_addScoringParameters(
   SCIP* scip  /**< SCIP data structure */
)
{
   SCIP_CALL(UT_addBoolParam(scip,
                             "gobnilp/scoring/prune",
                             "whether to prune during scoring",
                             TRUE
                            ));

   SCIP_CALL(UT_addIntParam(scip,
                            "gobnilp/scoring/rmin",
                            "minimum number of datapoints to create a branch in the AD tree",
                            2000, 0, INT_MAX
                           ));

   SCIP_CALL(UT_addIntParam(scip,
                            "gobnilp/scoring/adtreedepthlim",
                            "limit on the depth of the AD tree",
                            1000, 0, INT_MAX
                           ));

   SCIP_CALL(UT_addIntParam(scip,
                            "gobnilp/scoring/adtreenodeslim",
                            "limit on the number of nodes in  the AD tree",
                            10000, 0, INT_MAX
                           ));


   SCIP_CALL(UT_addIntParam(scip,
                            "gobnilp/scoring/cachesizelimit",
                            "limit on number of scores that are cached",
                            10000000, 0, INT_MAX
                           ));

   SCIP_CALL(UT_addIntParam(scip,
                            "gobnilp/scoring/cacheblocksize",
                            "how much to increase the cache when needed and allowed",
                            10000, 0, INT_MAX
                           ));

   SCIP_CALL(UT_addIntParam(scip,
                            "gobnilp/scoring/nvarscachelimit",
                            "subsets must have size below this to be cached",
                            50, 0, INT_MAX
                           ));


   SCIP_CALL(UT_addIntParam(scip,
                            "gobnilp/scoring/palim",
                            "maximum number of parents for each node (-1 for no limit)",
                            3, -1, INT_MAX
                           ));

   SCIP_CALL(UT_addRealParam(scip,
                             "gobnilp/scoring/alpha",
                             "alpha value for use in BDeu scoring",
                             1, 0, SCIPinfinity(scip)
                            ));

   SCIP_CALL(UT_addBoolParam(scip,
                             "gobnilp/scoring/names",
                             "whether variable names are given in the data file",
                             TRUE
                            ));

   SCIP_CALL(UT_addBoolParam(scip,
                             "gobnilp/scoring/arities",
                             "whether variable arities are given in the data file",
                             TRUE
                            ));

   SCIP_CALL(UT_addRealParam(scip,
                             "gobnilp/scoring/prunegap",
                             "If Pa1 and Pa2 are parent sets for some variable, Pa1 is a subset of Pa2 and local_score(Pa1) >= local_score(Pa2) - prunegap then Pa2 will be pruned",
                             0, 0, SCIPinfinity(scip)
                            ));

   SCIP_CALL(UT_addBoolParam(scip,
                             "gobnilp/scoring/fast",
                             "whether to fast scoring (which is inaccurate for high values of ESS)",
                             TRUE
                            ));



   return SCIP_OKAY;
}
/** Record local scores for parent sets of a particular child */
static SCIP_RETCODE addParentSets(
   SCIP* scip,                      /**< SCIP data structure */
   VARIABLE child,                  /**< Child variable whose scored parent sets are being added */
   SCORED_PARENTSET** parent_sets,  /**< Scored parent sets for child */
   int num_parent_sets,             /**< The number of scored parent sets for child */
   ParentSetData* psd,              /**< Parent set data to populate */
   SCIP_Real*** scores              /**< (*scores)[child][j] will be the score for the jth parent set of child */
)
{
   int i, j;

   psd->nParentSets[child] = num_parent_sets;

   SCIP_CALL( SCIPallocMemoryArray(scip, &(psd->nParents[child]),   num_parent_sets) );
   SCIP_CALL( SCIPallocMemoryArray(scip, &(psd->ParentSets[child]), num_parent_sets) );
   SCIP_CALL( SCIPallocMemoryArray(scip, &((*scores)[child]),       num_parent_sets) );

   for( i = 0; i < num_parent_sets; i++ )
   {
      (*scores)[child][i] = parent_sets[i]->score;
      psd->nParents[child][i] = parent_sets[i]->nvars;
      SCIP_CALL( SCIPallocMemoryArray(scip, &(psd->ParentSets[child][i]), parent_sets[i]->nvars) );
      for( j = 0; j < parent_sets[i]->nvars; j++ )
         psd->ParentSets[child][i][j] = parent_sets[i]->vars[j];
   }
   return SCIP_OKAY;
}

static int lookup(char** names, ARITY length, ARITY* used, char* name)
{
   ARITY i;
   for( i = 0; i < (*used); i++ )
      if( strcmp(names[i], name) == 0 )
         /* Found it */
         return i;
   if( i < length )
   {
      /* Not found but space to create it */
      sprintf(names[i], "%s", name);
      (*used)++;
      return i;
   }
   else
   {
      /* Not found and no space for it */
      return -1;
   }
}

static SCIP_RETCODE readProblemFromFile(
   SCIP* scip,
   const char* filename,
   int num_delims,
   char* delims,
   SCIP_Bool merge_delims,
   char*** nodeNames,
   ARITY** arities,
   VALUE*** items,
   int* num_vars,
   int* num_rows,
   char**** labels,
   int** num_observed
)
{
   FILE* file;

   char*** lines;
   int num_lines;
   int* line_lengths;

   SCIP_Bool hasNames;
   SCIP_Bool hasArities;

   char*** label_map;
   ARITY* label_map_count;

   int i, j, k;

   ARITY i_arity;

   int tmp_arity;

   /* Read the data from the file */
   if( strcmp(filename, "-") == 0 )
      file = stdin;
   else
      file = fopen(filename, "r");
   if( file == NULL )
   {
      SCIPerrorMessage("Could not open file %s.\n", filename);
      return SCIP_NOFILE;
   }
   SCIP_CALL( UT_readFileAndSplit(scip, file, delims, num_delims, merge_delims, &lines, &num_lines, &line_lengths) );
   fclose(file);

   /* Check the number of lines is ok */
   SCIPgetBoolParam(scip, "gobnilp/scoring/names", &hasNames);
   SCIPgetBoolParam(scip, "gobnilp/scoring/arities", &hasArities);
   (*num_rows) = 0;
   for( i = 0; i < num_lines; i++ )
      if( lines[i][0][0] != '#' )
         (*num_rows)++;
   if( hasNames )
      (*num_rows)--;
   if( hasArities )
      (*num_rows)--;
   if( (ROW)(*num_rows) > UINT_MAX )
   {
      SCIPerrorMessage("Warning: Too many rows to store them as unsigned  ints.\n");
      return SCIP_READERROR;
   }
   /* Check the line lengths are all ok */
   (*num_vars) = -1;
   for( i = 0; i < num_lines; i++ )
   {
      if( lines[i][0][0] == '#' )
      {
         /* Comment line, so do nothing */
      }
      else if( (*num_vars) < 0 )
      {
         /* Found the first line which wasn't a comment */
         (*num_vars) = line_lengths[i];
      }
      else if( line_lengths[i] != (*num_vars) )
      {
         /* Line is wrong length */
         SCIPerrorMessage("Wrong number of data items on line %d.  Found %d when %d were expected.\n", i + 1, line_lengths[i], (*num_vars));
         return SCIP_READERROR;
      }
      else
      {
         /* Line is correct length.  Do nothing */
      }
   }

   /* Get names */
   SCIP_CALL( SCIPallocMemoryArray(scip, nodeNames, (*num_vars)) );
   for( i = 0; i < (*num_vars); i++ )
      SCIP_CALL( SCIPallocMemoryArray(scip, &((*nodeNames)[i]), SCIP_MAXSTRLEN) );
   if( hasNames )
   {
      /* First non-comment line will be names */
      int name_line = 0;
      while( lines[name_line][0][0] == '#' )
         name_line++;
      for( j = 0; j < (*num_vars); j++ )
         sprintf((*nodeNames)[j], "%s", lines[name_line][j]);
   }
   else
   {
      /* No names - so use column numbers */
      for( i = 0; i < (*num_vars); i++ )
         sprintf((*nodeNames)[i], "%d", i);
   }

   /* Get arities */
   SCIP_CALL( SCIPallocMemoryArray(scip, arities, (*num_vars)) );
   if( hasArities )
   {
      /* First non-comment line will be arities, or second if names are being used */
      int arity_line = 0;
      if( hasNames )
      {
         while( lines[arity_line][0][0] == '#' )
            arity_line++;
         arity_line++;
      }
      while( lines[arity_line][0][0] == '#' )
         arity_line++;
      for( j = 0; j < (*num_vars); j++ )
      {
         /* use %d to skip whitespace */
         sscanf(lines[arity_line][j], "%d", &tmp_arity);
         (*arities)[j] = (ARITY) tmp_arity;
      }
   }
   else
   {
      /* No arities - so use biggest possible values for now */
      for( i = 0; i < (*num_vars); i++ )
         (*arities)[i] = MAXARITY;
   }

   /* Get values */
   SCIP_CALL( SCIPallocMemoryArray(scip, items, (*num_vars)) );
   for( i = 0; i < (*num_vars); i++ )
      SCIP_CALL( SCIPallocMemoryArray(scip, &((*items)[i]), (*num_rows)) );

   SCIP_CALL( SCIPallocMemoryArray(scip, &label_map, (*num_vars)) );
   SCIP_CALL( SCIPallocMemoryArray(scip, &label_map_count, (*num_vars)) );
   for( i = 0; i < (*num_vars); i++ )
   {
      label_map_count[i] = 0;
      SCIP_CALL( SCIPallocMemoryArray(scip, &(label_map[i]), (*arities)[i]) );
      for( i_arity = 0; i_arity < (*arities)[i]; i_arity++ )
         SCIP_CALL( SCIPallocMemoryArray(scip, &(label_map[i][i_arity]), SCIP_MAXSTRLEN) );
   }

   i = 0;
   if( hasNames )
   {
      while( lines[i][0][0] == '#' )
         i++;
      i++;
   }
   if( hasArities )
   {
      while( lines[i][0][0] == '#' )
         i++;
      i++;
   }
   for( j = 0; j < (*num_rows); j++ )
   {
      while( lines[i][0][0] == '#' )
         i++;
      for( k = 0; k < (*num_vars); k++ )
      {
         int value = lookup(label_map[k], (*arities)[k], &(label_map_count[k]), lines[i][k]);
         if( value == -1 )
         {
            SCIPerrorMessage("Invalid value %s for variable %d on row %d (%d values have already been seen)\n", lines[i][k], k, i, (*arities)[i]);
            return SCIP_READERROR;
         }
         (*items)[k][j] = value;
      }
      i++;
   }

   /* Work out arities if they weren't given */
   if( !hasArities )
   {
      for( i = 0; i < (*num_vars); i++ )
         (*arities)[i] = label_map_count[i];
   }

   SCIP_CALL( SCIPallocMemoryArray(scip, labels, (*num_vars)) );
   for( i = 0; i < (*num_vars); i++ )
   {
      SCIP_CALL( SCIPallocMemoryArray(scip, &((*labels)[i]), (*arities)[i]) );
      for( i_arity = 0; i_arity < (*arities)[i]; i_arity++ )
      {
         SCIP_CALL( SCIPallocMemoryArray(scip, &((*labels)[i][i_arity]), SCIP_MAXSTRLEN) );
         if( i_arity < label_map_count[i] )
            sprintf((*labels)[i][i_arity], "%s", label_map[i][i_arity]);
         else
            sprintf((*labels)[i][i_arity], "UNKNOWN");
      }
   }

   SCIP_CALL( SCIPallocMemoryArray(scip, num_observed, (*num_vars)) );
   for( i = 0; i < (*num_vars); i++ )
   {
      (*num_observed)[i] = label_map_count[i];
   }

   /* Tidy up */
   for( i = 0; i < num_lines; i++ )
   {
      for( j = 0; j < line_lengths[i]; j++ )
         SCIPfreeMemoryArray(scip, &(lines[i][j]));
      SCIPfreeMemoryArray(scip, &(lines[i]));
   }
   SCIPfreeMemoryArray(scip, &lines);
   SCIPfreeMemoryArray(scip, &line_lengths);
   for( i = 0; i < (*num_vars); i++ )
   {
      for( i_arity = 0; i_arity < (*arities)[i]; i_arity++ )
         SCIPfreeMemoryArray(scip, &(label_map[i][i_arity]));
      SCIPfreeMemoryArray(scip, &(label_map[i]));
   }
   SCIPfreeMemoryArray(scip, &label_map);
   SCIPfreeMemoryArray(scip, &label_map_count);

   return SCIP_OKAY;
}

/** Read data in from a file, generate and store local scores */
SCIP_RETCODE SC_readProblemInDataFormat(
   SCIP* scip,                  /**< SCIP data structure */
   const char* filename,        /**< File containing the data */
   int num_delims,              /**< Mark to do */
   char* delims,                /**< Mark to do */
   SCIP_Bool merge_delims,      /**< Mark to do */
   ParentSetData* psd,          /**< Parent set data to populate */
   SCIP_Real*** scores,         /**< (*scores)[child][j] will be the score for the jth parent set of child */
   PropertyData* prop           /**< Mark to do */
)
{
   int i;
   int k;
   int kk;
   int tmp_k;
   VARIABLE var;
   VARIABLE var2;
   ARITY biggest_arity = 0;
   ARITY i_arity;

   int npa;
   int old_layer_size;
   int new_layer_size;
   VARIABLE **old_layer_vars;
   VARIABLE **new_layer_vars;
   int old_layer_index;
   int lower_bound;

   VARIABLE *old_vars_ptr = NULL;

   VARIABLE *new_vars_ptr;

   VARIABLE new_parent;
   VARIABLE child;
   double skore;

   SCIP_Bool* a_parent;
   int n_kept;
   int n_new_kept;
   SCORED_PARENTSET *sps_ptr;
   SCORED_PARENTSET **kept;
   SCORED_PARENTSET **new_kept;
   SCORED_PARENTSET **tmp_kept;
   SCIP_Bool keep;
   SCIP_Bool subset;
   SCIP_Bool prune;
   SCIP_Bool pruning;

   int new_layer_allocated;
   int new_kept_allocated;

   SCIP_Bool last_layer;
   SUBSET_TREE *subsets;
   VARIABLE* subset_ptr;

   int* num_observed;
   char*** variable_values;

   double prunegap;

   /* ADTREE */
   ADTREE *adtree = malloc(sizeof(ADTREE));
   ROW* allrows;
   VARIABLE *family;

   double threshold;

   int rmin;
   int adtreedepthlim;
   int adtreenodeslim;

   int nvars_choose_i;
   int accumulator;
   COUNT npos_cells;

   int n_nodes = 0;

   int** is_parent;
   VARIABLE** is_parents;
   int*  n_is_parents;
   SCIP_Bool ok;
   SCIP_Bool overflow;

   SCIPgetRealParam(scip, "gobnilp/scoring/alpha", &alpha);
   SCIPgetIntParam(scip, "gobnilp/scoring/palim", &palim);
   SCIPgetBoolParam(scip, "gobnilp/scoring/prune", &pruning);
   SCIPgetRealParam(scip, "gobnilp/scoring/prunegap", &prunegap);
   SCIPgetBoolParam(scip, "gobnilp/scoring/fast", &fast);
   SCIPgetIntParam(scip, "gobnilp/scoring/cachesizelimit", &cachesizelimit);
   SCIPgetIntParam(scip, "gobnilp/scoring/cacheblocksize", &cacheblocksize);
   SCIPgetIntParam(scip, "gobnilp/scoring/nvarscachelimit", &nvarscachelimit);

   SCIP_CALL( readProblemFromFile(scip, filename, num_delims, delims, merge_delims, &(psd->nodeNames), &arity, &data, (int *) &nvars, &nrows, &variable_values, &num_observed) );
   psd->n = nvars;

   SCIP_CALL( SCIPallocMemoryArray(scip, &is_parent, nvars) );
   SCIP_CALL( SCIPallocMemoryArray(scip, &is_parents, nvars) );
   SCIP_CALL( SCIPallocMemoryArray(scip, &n_is_parents, nvars) );
   for( var = 0; var < nvars; ++var )
   {
      SCIP_CALL( SCIPallocMemoryArray(scip, &(is_parent[var]), nvars) );
      SCIP_CALL( SCIPallocMemoryArray(scip, &(is_parents[var]), nvars) );
      n_is_parents[var] = 0;
      for( var2 = 0; var2 < nvars; ++var2 )
         is_parent[var][var2] = 0;
   }

   /* find any parents/nonparents */
   addGeneralDAGConstraints(scip, psd, is_parent);

   for( var = 0; var < nvars; ++var )
      for( var2 = 0; var2 < nvars; ++var2 )
         if( is_parent[var][var2] )
            is_parents[var][n_is_parents[var]++] = var2;

   allrows = (ROW *) malloc(nrows * sizeof(ROW));
   for( i = 0; i < nrows; ++i )
      allrows[i] = i;

   SCIPgetIntParam(scip, "gobnilp/scoring/rmin", &rmin);
   SCIPgetIntParam(scip, "gobnilp/scoring/adtreedepthlim", &adtreedepthlim);
   SCIPgetIntParam(scip, "gobnilp/scoring/adtreenodeslim", &adtreenodeslim);
   SCIPverbMessage(scip, SCIP_VERBLEVEL_FULL, NULL, "Building the AD tree ...");
   build_adtree(adtree, 0, allrows, nrows, rmin, 0, &n_nodes, adtreedepthlim, adtreenodeslim);
   SCIPverbMessage(scip, SCIP_VERBLEVEL_FULL, NULL, " Done\n");
   if( palim == -1 )
      palim = nvars;

   for( var = 0; var < nvars; ++var )
      if( arity[var] > biggest_arity )
         biggest_arity = arity[var];

   SCIP_CALL( SCIPallocMemoryArray(scip, scores, nvars) );
   SCIP_CALL( SCIPallocMemoryArray(scip, &(psd->nParentSets), nvars) );
   SCIP_CALL( SCIPallocMemoryArray(scip, &(psd->nParents), nvars) );
   SCIP_CALL( SCIPallocMemoryArray(scip, &(psd->ParentSets), nvars) );


   /* set up temporary working areas */
   a_parent = (SCIP_Bool *) malloc(nvars * sizeof(SCIP_Bool));
   subset_ptr = (VARIABLE *) malloc((nvars - 1) * sizeof(VARIABLE));

   for(  var = 0; var < nvars; ++var  ) 
      a_parent[var] = FALSE; 


   /* for caching */
   /* may have subsets of sizes 0,1,... nvars */
   SCIP_CALL( SCIPallocMemoryArray(scip, &nsubsets, nvars + 1) );
   cachesize = cacheblocksize;
   SCIP_CALL( SCIPallocMemoryArray(scip, &llh_cache, cachesize) );
   SCIP_CALL( SCIPallocMemoryArray(scip, &pos_cells_cache, cachesize) );
   /* a count of zero is a dummy value, indicating that the true count
      ( as well as the true log-likelihood ) has not yet been calculated */
   for( i = 0; i < cachesize; ++i )
      pos_cells_cache[i] = 0;


   /* if m is size of largest cached subset then need to computer nsubsets[i]
      for i = 0,1,2,3,...m
      m is the minimum of:
      1) palim+1
      2) nvars
      3) nvarscachelimit-1
   */
   /*printf("nvars = %d\n",nvars);*/
   accumulator = 0;
   overflow = FALSE;
   for( i = 0; i <= min(min((int) nvars, nvarscachelimit - 1), palim + 1); ++i )
   {
    
      nsubsets[i] = accumulator;

      nvars_choose_i = 1;
      for( k = 0; k < i; ++k )
      {
         if( nvars_choose_i > INT_MAX / (int) (nvars - k) )
         {
            overflow = TRUE;
            break;
         }
         nvars_choose_i *= (nvars - k);
         nvars_choose_i /= (k + 1);
      }
      if( INT_MAX - nvars_choose_i < accumulator )
         overflow = TRUE;
      else
         accumulator += nvars_choose_i;
      
      assert(accumulator > 0);
    
      /* accumulator is the highest rank of subsets of size i
         if accumulator is above INT_MAX then it is unsafe to compute
         ranks for subsets of this size, so set nvarscachelimit to 
         stop this happening
      */


      if( overflow )
      {
         nvarscachelimit = i;
         break;
      }

      /* if accumulator has reached cachesizelimit then no point in ranking
         subsets of size greater than i
      */

      
      if( accumulator >= cachesizelimit )
      {
         nvarscachelimit = i+1;
         break;
      }         
  
   }

   /* compute local scores, one child at a time */
   for( child = 0; child < nvars; ++child )
   {

      double logaritychild = log(arity[child]);

      SCIPdebugMessage("Computing local scores for child %d (%s)\n",child,psd->nodeNames[child]);

      /* initialise subset store */
      subsets = (SUBSET_TREE *) malloc(sizeof(SUBSET_TREE));
      subsets->children = (SUBSET_TREE **) malloc(nvars * sizeof(SUBSET_TREE *));
      for( var = 0; var < nvars; ++var )
         (subsets->children)[var] = NULL;


      /* no previous 'old layer' for this child so initialise it directly
         to contain just the empty parent set */

      old_layer_vars = (VARIABLE **) malloc(sizeof(VARIABLE *));
      old_layer_vars[0] = NULL;
      old_layer_size = 1;

      /* score the empty parent set for this child */

      family = (VARIABLE *) malloc(sizeof(VARIABLE));
      family[0] = child;

      skore = -log_likelihood_cache(scip, adtree, NULL, 0, &npos_cells);
      skore += log_likelihood_cache(scip, adtree, family, 1, &npos_cells);
      free(family);

      /* this parent set and its score always kept */

      sps_ptr = (SCORED_PARENTSET *) malloc(sizeof(SCORED_PARENTSET));
      sps_ptr->score = skore;
      sps_ptr->nvars = 0;
      sps_ptr->vars = NULL;
      kept = (SCORED_PARENTSET **) malloc(sizeof(SCORED_PARENTSET *));
      kept[0] = sps_ptr;
      n_kept = 1;
      last_layer = FALSE;

      /* now compute local scores for increasing numbers of parents */

      for( npa = 1; npa <= min(palim, (int) nvars - 1); ++npa )
      {

         if( npa == min(palim, (int) nvars - 1) )
            last_layer = TRUE;

         /* create initial space for new layer */

         new_layer_allocated = BLOCKSIZE;
         new_kept_allocated = BLOCKSIZE;
         new_layer_vars = (VARIABLE **) malloc(new_layer_allocated * sizeof(VARIABLE *));
         new_kept = (SCORED_PARENTSET **) malloc(new_kept_allocated * sizeof(SCORED_PARENTSET *));

         n_new_kept = 0;
         new_layer_size = 0;

         for( old_layer_index = 0; old_layer_index < old_layer_size; ++old_layer_index )
         {
            /* grab an 'old' parent set to extend */

            old_vars_ptr = old_layer_vars[old_layer_index];

            if( old_vars_ptr == NULL )
               lower_bound = -1;
            else
               lower_bound = old_vars_ptr[npa - 2];

            /* extend old parent set to create new parent sets
               by adding new parents strictly greater
               than any in the old parent set
            */

            for( new_parent = lower_bound + 1; new_parent < nvars; ++new_parent )
            {

               /* just skip over 'banned' parents */
               if( new_parent == child || is_parent[child][new_parent] == -1 )
                  continue;

               /* create new parent set */

               new_vars_ptr = (VARIABLE *) malloc(npa * sizeof(VARIABLE));
               for( k = 0; k < npa - 1; ++k )
                  new_vars_ptr[k] = old_vars_ptr[k];
               new_vars_ptr[k] = new_parent;

               /* check that all subsets of new_vars
                  are in the subset store
               */

               prune = FALSE;
               if( pruning && npa > 1 )
               {
                  subset_ptr[npa - 2] = new_parent;
                  for( kk = 0; kk < npa - 1; ++kk )
                  {
                     tmp_k = 0;
                     for( k = 0; k < npa - 1; ++k )
                        if( k != kk )
                           subset_ptr[tmp_k++] = old_vars_ptr[k];

                     if( !check_subset(subsets, subset_ptr, npa - 1, 0) )
                     {
#ifdef SCIP_DEBUG
                        SCIPdebugMessage("Pruning and not scoring parent set:");
                        for( k = 0; k < npa; ++k )
                           printf("%d (%s) ", new_vars_ptr[k], psd->nodeNames[new_vars_ptr[k]]);
                        printf("\nSince this parent set not found in store:");
                        for( k = 0; k < npa - 1; ++k )
                           printf("%d (%s) ", subset_ptr[k], psd->nodeNames[subset_ptr[k]]);
                        printf("\n");
#endif
                        
                        prune = TRUE;
                        break;
                     }
                  }
               }


               if( prune )
               {
                  free(new_vars_ptr);
                  continue;
               }

               skore = -log_likelihood_cache(scip, adtree, new_vars_ptr, npa, &npos_cells);
               threshold = -logaritychild * npos_cells;

               /* create family by inserting child */

               family = (VARIABLE *) malloc((npa + 1) * sizeof(VARIABLE));
               k = 0;
               while( k < npa && new_vars_ptr[k] < child )
               {
                  family[k] = new_vars_ptr[k];
                  k++;
               }
               family[k] = child;
               while( k < npa )
               {
                  family[k + 1] = new_vars_ptr[k];
                  k++;
               }
               skore += log_likelihood_cache(scip, adtree, family, npa + 1, &npos_cells);

               /* if(  skore > 0  ) */
               /* { */
               /*    printf("child %d\n", child); */
               /*    for( i = 0; i < npa+1; ++i  ) */
               /*       printf("%d ",family[i]); */
               /*    printf("%f \n", skore); */
               /*    exit(1); */
               /* } */

               free(family);

               /* set up bit set representation of new parent set
                  for fast subset checking */

               keep = TRUE;
               if( pruning )
               {
                  for( k = 0; k < npa; ++k )
                     a_parent[new_vars_ptr[k]] = TRUE;

                  /* decide whether to keep/prune this scored parentset */

                  for( i = 0; i < n_kept; ++i )
                  {
                     sps_ptr = kept[i];
                     if( skore > sps_ptr->score + prunegap )
                        /* will also have better score than the rest
                           since scores are ordered best first */
                        break;
                     subset = TRUE;
                     for( k = 0; k < sps_ptr->nvars; ++k )
                        if( ! a_parent[sps_ptr->vars[k]] )
                        {
                           subset = FALSE;
                           break;
                        }
                     if( subset )
                     {
                        /* found a subset with a better score */
                        keep = FALSE;
#ifdef SCIP_DEBUG
                        SCIPdebugMessage("Not keeping this parent set:{ ");
                        for( k = 0; k < npa; ++k )
                           printf("%d (%s) ", new_vars_ptr[k], psd->nodeNames[new_vars_ptr[k]]);
                        printf(" } with score %f\nSince this parent set: { ", skore);
                        for( k = 0; k < sps_ptr->nvars; ++k )
                           printf("%d (%s) ", sps_ptr->vars[k], psd->nodeNames[sps_ptr->vars[k]]);
                        printf(" } has score %f (prunegap is %f)\n", sps_ptr->score, prunegap);
#endif

                        /* de Campos and Ji style (without checking for small alpha ) */
                        if( (!last_layer) && (sps_ptr->score > threshold) )
                        {
                           SCIPdebugMessage("Also 'exponentially' pruned\n"); 
                           prune = TRUE;
                        }
                        break;
                     }
                  }
               }

               /* reset temporary memory */
               for( k = 0; k < npa; ++k )
                  a_parent[new_vars_ptr[k]] = FALSE;


               /* now check whether parents which have to be there are there */
               if( keep )
               {
                  for( i = 0; i < n_is_parents[child]; ++i )
                  {
                     ok = FALSE;
                     for( k = 0; k < npa; ++k )
                        if( is_parents[child][i] == new_vars_ptr[k] )
                        {
                           ok = TRUE;
                           break;
                        }
                     if( !ok )
                     {
                        keep = FALSE;
                        break;
                     }
                  }
               }
               
               if( keep )
               {
#ifdef SCIP_DEBUG
                  SCIPdebugMessage("Keeping this parent set:{ ");
                  for( k = 0; k < npa; ++k )
                     printf("%d (%s) ", new_vars_ptr[k], psd->nodeNames[new_vars_ptr[k]]);
                  printf(" } with score %f\n", skore);
#endif
                  sps_ptr = (SCORED_PARENTSET *) malloc(sizeof(SCORED_PARENTSET));
                  sps_ptr->score = skore;
                  sps_ptr->nvars = npa;
                  sps_ptr->vars = (VARIABLE *) malloc(npa * sizeof(VARIABLE));
                  for( k = 0; k < npa; ++k )
                     sps_ptr->vars[k] = new_vars_ptr[k];
                  if( n_new_kept >= new_kept_allocated )
                  {
                     new_kept_allocated = new_kept_allocated + BLOCKSIZE;
                     new_kept = (SCORED_PARENTSET **) realloc(new_kept, new_kept_allocated * sizeof(SCORED_PARENTSET *));
                  }
                  new_kept[n_new_kept++] = sps_ptr;
               }

               /* store contabs, unless parent set is 'exponentially' pruned
                  or this is the last layer
               */
               if( prune || last_layer )
               {
                  free(new_vars_ptr);
               }
               else
               {
                  /*SCIPerrorMessage("%d %d\n",new_layer_max_size,new_layer_size);*/
                  if( new_layer_size >= new_layer_allocated )
                  {
                     new_layer_allocated = new_layer_allocated + BLOCKSIZE;
                     new_layer_vars = (VARIABLE **) realloc(new_layer_vars, new_layer_allocated * sizeof(VARIABLE *));
                  }
                  new_layer_vars[new_layer_size] = new_vars_ptr;
                  new_layer_size++;

                  if( pruning )
                     add_subset(subsets, new_vars_ptr, npa, 0);
               }
            }


            free(old_vars_ptr);
         }

         /* kill off old layer */

         free(old_layer_vars);

         /* here sort new_kept and then merge into kept */

         qsort(new_kept, n_new_kept, sizeof(SCORED_PARENTSET *), sps_sort);

         tmp_kept = (SCORED_PARENTSET **) malloc((n_kept + n_new_kept) * sizeof(SCORED_PARENTSET *));
         kk = 0;
         tmp_k = 0;
         for( k = 0; k < n_kept; ++k )
         {
            while( kk < n_new_kept && (new_kept[kk])->score > (kept[k])->score )
               tmp_kept[tmp_k++] = new_kept[kk++];
            tmp_kept[tmp_k++] = kept[k];
         }
         while( kk < n_new_kept )
            tmp_kept[tmp_k++] = new_kept[kk++];

         /* everything that needs to be kept, now in tmp_kept */
         free(kept);
         free(new_kept);
         kept = tmp_kept;
         n_kept = n_kept + n_new_kept;

         old_layer_vars = (VARIABLE **) realloc(new_layer_vars, new_layer_size * sizeof(VARIABLE *));
         old_layer_size = new_layer_size;
      }

      /* finished scoring parent sets for this child,
         but need a final clear up for this child */

      for( old_layer_index = 0; old_layer_index < old_layer_size; ++old_layer_index )
         free(old_layer_vars[old_layer_index]);
      free(old_layer_vars);

      delete_tree(subsets, nvars);

      /* store parent sets for this child */
      
      SCIPverbMessage(scip, SCIP_VERBLEVEL_FULL, NULL, "%d candidate parent sets for %s.\n", n_kept, psd->nodeNames[child]);

      SCIPdebugMessage("%d candidate parent sets for child %d.\n", n_kept, child);

      SCIP_CALL( addParentSets(scip, child, kept, n_kept, psd, scores) );
      for( k = 0; k < n_kept; ++k )
      {
         sps_ptr = kept[k];
         free(sps_ptr->vars);
         free(sps_ptr);
      }
      free(kept);
   }

   /* Set global properties */
   SCIP_CALL( PR_setGlobalProperty(scip, prop,           "scorer_name",    "GOBNILP") );
   SCIP_CALL( PR_setGlobalProperty(scip, prop,           "scorer_version", GOBNILP_VERSION) );
   SCIP_CALL( PR_setGlobalProperty(scip, prop,           "scorer_url",     "www.cs.york.ac.uk/aig/sw/gobnilp/") );
   SCIP_CALL( PR_setGlobalProperty(scip, prop,           "score_type",     "BDeu") );
   SCIP_CALL( PR_setGlobalPropertyFromReal(scip, prop,   "ess",            alpha) );
   SCIP_CALL( PR_setGlobalPropertyFromInt(scip, prop,    "parent_limit",   palim) );
   SCIP_CALL( PR_setGlobalPropertyFromBool(scip, prop,   "pruning",        pruning) );
   SCIP_CALL( PR_setGlobalPropertyFromInt(scip, prop,    "num_records",    nrows) );
   SCIP_CALL( PR_setGlobalProperty(scip, prop,           "input_file",     filename) );

   /* Set the individual properties */
   prop->n = nvars;
   for( i = 0; i < prop->n; i++ )
   {
      SCIP_CALL( PR_setPropertyFromInt(scip, prop, i, "arity", arity[i]) );
      SCIP_CALL( PR_setPropertyFromArray(scip, prop, i, "values", (const char**)variable_values[i], num_observed[i]) );
      if( num_observed[i] < (int) arity[i] )
         SCIP_CALL( PR_setPropertyFromInt(scip, prop, i, "num_unobserved_values", arity[i] - num_observed[i]) );
   }

   /* tidy up */
   delete_adtree(adtree, 0);
   free(a_parent);
   free(subset_ptr);
   for( var = 0; var < nvars; var++ )
   {
      for( i_arity = 0; i_arity < arity[var]; i_arity++ )
         SCIPfreeMemoryArray(scip, &variable_values[var][i_arity]);
      SCIPfreeMemoryArray(scip, &variable_values[var]);
   }
   SCIPfreeMemoryArray(scip, &variable_values);
   for( var = 0; var < nvars; ++var )
   {
      SCIPfreeMemoryArray(scip, &(data[var]));
      SCIPfreeMemoryArray(scip, &(is_parent[var]));
      SCIPfreeMemoryArray(scip, &(is_parents[var]));
   }
   SCIPfreeMemoryArray(scip, &num_observed);
   SCIPfreeMemoryArray(scip, &data);
   SCIPfreeMemoryArray(scip, &arity);
   SCIPfreeMemoryArray(scip, &is_parent);
   SCIPfreeMemoryArray(scip, &is_parents);
   SCIPfreeMemoryArray(scip, &n_is_parents);

   SCIPfreeMemoryArray(scip, &llh_cache);
   SCIPfreeMemoryArray(scip, &pos_cells_cache);
   SCIPfreeMemoryArray(scip, &nsubsets);

   return SCIP_OKAY;
}
